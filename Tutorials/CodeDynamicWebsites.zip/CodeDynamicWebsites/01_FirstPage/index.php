<!DOCTYPE html>
<html>
	<head>
		<title>My First PHP Web Page</title>
	</head>
	<body>
		<?php print('Hello World!'); ?>
	</body>
</html>
